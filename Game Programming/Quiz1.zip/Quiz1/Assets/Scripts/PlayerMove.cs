﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerMove : MonoBehaviour
{
    // Start is called before the first frame update
    private float moveInput;
    private Rigidbody2D rb;
    private bool isGrounded;
    private float speed = 5;
    private float jumpForce = 5;

    public Transform groundCheck;
    public LayerMask whatIsGround;
    public float checkRadius = 1f;

    private Color platformColor;
    private GameObject platform;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>(); 
    }

    // Update is called once per frame
    void Update()
    {
        if (isGrounded == true && Input.GetKeyDown(KeyCode.UpArrow))
        {
            rb.velocity = Vector2.up * jumpForce;
        }
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        //gameObject.GetComponent(Color).material.color = Color.blue;
        //gameObject.GetComponent().material.color = other.gameObject.material.color;

        //platform = GameObject.Find("Platform");
        //platformColor = other.gameObject.GetComponent<Renderer>().material.color;

        platformColor = other.gameObject.GetComponent<Renderer>().material.color;
        GetComponent<Renderer>().material.color = platformColor;
    }

    private void FixedUpdate()
    {
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, checkRadius, whatIsGround);
        //is circle positioned around groundcheck, if radius is touching what is ground. 
        moveInput = Input.GetAxis("Horizontal");
        rb.velocity = new Vector2(moveInput * speed, rb.velocity.y);
    }
}
